from flask import Flask
from aiogoogletrans import Translator
import asyncio
app = Flask(__name__)

translator = Translator()
loop = asyncio.get_event_loop()

@app.route('/')
def home():
    return "Welcome to translator api!!!"

@app.route('/api/v1/translate/<dest>/<text>')
def translate(dest, text):
    result = loop.run_until_complete(translator.translate(text, dest=dest))
    data = {}
    data['translatedText'] = result.text
    return data

if __name__ == '__main__':
    app.run()